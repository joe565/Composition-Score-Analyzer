# Composition Score Analyzer — Simple Version

A Python tool for research-oriented analysis of student writing stored in Excel workbooks.

The script automatically identifies a likely writing column, analyzes each response, and appends linguistic measures to the workbook.

## Measures

- Grammar errors per 100 words
- MTLD lexical diversity
- Average sentence length
- Clauses per sentence
- Flesch-Kincaid grade level

## Requirements

- Python 3
- Java (required by LanguageTool)
- spaCy English model `en_core_web_sm`

Install the Python packages:

```bash
pip install -r requirements.txt
```

Install the spaCy English model:

```bash
python -m spacy download en_core_web_sm
```

## Usage

```bash
python3 composition_score_analysis_simple.py "/path/to/workbook.xlsx"
```

Optional arguments:

```bash
python3 composition_score_analysis_simple.py workbook.xlsx --sheet "Sheet1" --text-column 3
```

`--text-column` uses a 1-based Excel column number. If it is omitted, the program attempts to identify the writing column automatically.

## Output

The program adds five new columns to the selected worksheet and saves the results back to the same Excel workbook.

## Research Note

The individual linguistic measures are intended to be interpretable research variables rather than a proprietary or validated holistic writing score. Results should be evaluated within the design and limitations of the study in which the tool is used.
