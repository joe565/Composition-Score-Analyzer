#!/usr/bin/env python3
"""
Simple research-oriented writing analysis for Excel workbooks.

Measures:
1. Grammar errors per 100 words
2. MTLD lexical diversity
3. Average sentence length
4. Clauses per sentence
5. Flesch-Kincaid Grade Level

Install:
    pip install openpyxl spacy language-tool-python textstat
    python -m spacy download en_core_web_sm

Run:
    python3 composition_score_analysis_simple.py "/path/to/workbook.xlsx"
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import List

import language_tool_python
import spacy
import textstat
from openpyxl import load_workbook


TEXT_HINTS = (
    "essay",
    "text",
    "response",
    "answer",
    "paragraph",
    "composition",
    "writing",
    "reflection",
    "comment",
    "summary",
)

WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")

# Load NLP tools once.
NLP = spacy.load("en_core_web_sm")
LANGUAGE_TOOL = language_tool_python.LanguageTool("en-US")


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def get_words(text: str) -> List[str]:
    return [w.lower() for w in WORD_RE.findall(text)]


def mtld(words: List[str], threshold: float = 0.72) -> float:
    """
    Compute Measure of Textual Lexical Diversity (MTLD).

    Higher values generally indicate greater lexical diversity.
    """
    if not words:
        return 0.0

    def one_direction(tokens: List[str]) -> float:
        factors = 0.0
        types = set()
        token_count = 0

        for token in tokens:
            token_count += 1
            types.add(token)
            ttr = len(types) / token_count

            if ttr <= threshold:
                factors += 1.0
                types = set()
                token_count = 0

        if token_count > 0:
            ttr = len(types) / token_count
            if ttr != 1.0:
                factors += (1.0 - ttr) / (1.0 - threshold)

        return len(tokens) / factors if factors else float(len(tokens))

    forward = one_direction(words)
    backward = one_direction(list(reversed(words)))
    return (forward + backward) / 2.0


def grammar_errors_per_100(text: str, word_count: int) -> float:
    """
    Count LanguageTool grammar/style issues per 100 words.

    Obvious spelling-only matches are excluded when LanguageTool exposes
    them as misspelling issues.
    """
    if word_count == 0:
        return 0.0

    matches = LANGUAGE_TOOL.check(text)
    grammar_matches = []

    for match in matches:
        issue_type = str(getattr(match, "ruleIssueType", "")).lower()
        if issue_type == "misspelling":
            continue
        grammar_matches.append(match)

    return (len(grammar_matches) / word_count) * 100.0


def clauses_per_sentence(doc) -> float:
    """
    Approximate syntactic complexity as clauses per sentence using spaCy
    dependency labels that commonly introduce independent or dependent clauses.
    """
    sentences = list(doc.sents)
    if not sentences:
        return 0.0

    clause_dependencies = {
        "ROOT",
        "advcl",
        "ccomp",
        "xcomp",
        "relcl",
        "acl",
        "parataxis",
    }

    total_clauses = 0

    for sentence in sentences:
        clause_count = sum(
            1
            for token in sentence
            if token.dep_ in clause_dependencies
            and token.pos_ in {"VERB", "AUX"}
        )

        # Treat each non-empty sentence as containing at least one clause.
        total_clauses += max(1, clause_count)

    return total_clauses / len(sentences)


def analyze_text(text: str) -> dict:
    text = normalize_text(text)

    metric_names = [
        "Grammar Errors / 100 Words",
        "MTLD",
        "Average Sentence Length",
        "Clauses / Sentence",
        "Flesch-Kincaid Grade",
    ]

    if not text:
        return {name: None for name in metric_names}

    words = get_words(text)
    word_count = len(words)

    doc = NLP(text)
    sentences = list(doc.sents)
    sentence_count = max(1, len(sentences))

    return {
        "Grammar Errors / 100 Words": round(
            grammar_errors_per_100(text, word_count), 3
        ),
        "MTLD": round(mtld(words), 3),
        "Average Sentence Length": round(word_count / sentence_count, 3),
        "Clauses / Sentence": round(clauses_per_sentence(doc), 3),
        "Flesch-Kincaid Grade": round(
            float(textstat.flesch_kincaid_grade(text)), 3
        ),
    }


def find_text_column(ws) -> int:
    """Guess which worksheet column contains the student writing."""
    max_row = ws.max_row
    max_col = ws.max_column

    # First, look for likely header names.
    for col in range(1, max_col + 1):
        header = str(ws.cell(row=1, column=col).value or "").strip().lower()
        if any(hint in header for hint in TEXT_HINTS):
            return col

    # Otherwise choose the first column with multiple long text entries.
    for col in range(1, max_col + 1):
        text_like = 0
        for row in range(2, min(max_row, 30) + 1):
            value = ws.cell(row=row, column=col).value
            if value is not None and len(str(value).strip()) >= 50:
                text_like += 1

        if text_like >= 2:
            return col

    return 1


def process_workbook(
    file_path: str,
    sheet_name: str | None = None,
    text_column: int | None = None,
) -> str:
    wb = load_workbook(file_path)

    if not wb.worksheets:
        raise ValueError("Workbook contains no worksheets.")

    ws = wb[sheet_name] if sheet_name else wb.active

    if text_column is None:
        text_column = find_text_column(ws)

    output_col = ws.max_column + 1

    metric_names = [
        "Grammar Errors / 100 Words",
        "MTLD",
        "Average Sentence Length",
        "Clauses / Sentence",
        "Flesch-Kincaid Grade",
    ]

    # Add output headers.
    for offset, metric in enumerate(metric_names):
        ws.cell(row=1, column=output_col + offset, value=metric)

    # Analyze each submission.
    for row in range(2, ws.max_row + 1):
        text = normalize_text(ws.cell(row=row, column=text_column).value)
        metrics = analyze_text(text)

        for offset, metric in enumerate(metric_names):
            ws.cell(
                row=row,
                column=output_col + offset,
                value=metrics[metric],
            )

    wb.save(file_path)

    return (
        f"Finished. Added {len(metric_names)} writing measures "
        f"to '{ws.title}' and saved: {file_path}"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze student writing in an Excel workbook."
    )

    parser.add_argument(
        "file_path",
        nargs="?",
        default=None,
        help="Path to Excel workbook (.xlsx/.xlsm).",
    )

    parser.add_argument(
        "--sheet",
        default=None,
        help="Optional worksheet name.",
    )

    parser.add_argument(
        "--text-column",
        type=int,
        default=None,
        help="1-based text column. Auto-detected if omitted.",
    )

    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if not args.file_path:
        args.file_path = input("Excel workbook path: ").strip()

    if not args.file_path:
        raise ValueError("No workbook path provided.")

    path = Path(args.file_path).expanduser().resolve()

    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    print(
        process_workbook(
            str(path),
            sheet_name=args.sheet,
            text_column=args.text_column,
        )
    )


if __name__ == "__main__":
    main()
